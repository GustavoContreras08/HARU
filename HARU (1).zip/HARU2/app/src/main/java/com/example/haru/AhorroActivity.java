    package com.example.haru;
    
    import android.content.Intent;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.Toast;
    
    import androidx.activity.EdgeToEdge;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.graphics.Insets;
    import androidx.core.view.ViewCompat;
    import androidx.core.view.WindowInsetsCompat;
    
    public class AhorroActivity extends BaseActivity {
    
        private int userId;
    
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_ahorro);
    
            userId = getIntent().getIntExtra("USER_ID", -1); // ✅ ID del usuario recibido de CasaActivity
    
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
    
            Button buttonir = findViewById(R.id.cancelar);
            buttonir.setOnClickListener(v -> cancelar());
    
            Button buttongas = findViewById(R.id.Gastar);
            buttongas.setOnClickListener(v -> gastar());
    
            Button buttonah = findViewById(R.id.button6);
            buttonah.setOnClickListener(v -> ahorrar());
        }
    
        private void cancelar() {
            Intent intent = new Intent(AhorroActivity.this, CasaActivity.class);
            intent.putExtra("USER_ID", userId); // puedes reenviar el ID si lo necesitas allá
            startActivity(intent);
        }

        private void gastar() {
            EditText editAhorro = findViewById(R.id.monto);
            String gastoStr = editAhorro.getText().toString();

            if (gastoStr.isEmpty()) {
                Toast.makeText(this, "Ingresa un monto para gastar", Toast.LENGTH_SHORT).show();
                return;
            }

            double monto = Double.parseDouble(gastoStr);
            if (monto <= 0) {
                Toast.makeText(this, "El monto debe ser mayor a cero", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("SELECT ahorro FROM Money WHERE UsuarioID = ?", new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                double ahorroActual = cursor.getDouble(cursor.getColumnIndexOrThrow("ahorro"));

                if (monto > ahorroActual) {
                    Toast.makeText(this, "No tienes suficiente ahorro para gastar esa cantidad", Toast.LENGTH_SHORT).show();
                    cursor.close();
                    db.close();
                    return;
                }

                double nuevoAhorro = ahorroActual - monto;
                db.execSQL("UPDATE Money SET ahorro = ? WHERE UsuarioID = ?", new Object[]{nuevoAhorro, userId});

                Toast.makeText(this, "Gasto registrado correctamente", Toast.LENGTH_SHORT).show();
                editAhorro.setText("");
            } else {
                Toast.makeText(this, "No se encontró registro de dinero para el usuario", Toast.LENGTH_SHORT).show();
            }

            cursor.close();
            db.close();
        }

        private void ahorrar() {
            EditText editAhorro = findViewById(R.id.monto);
            String ahorroStr = editAhorro.getText().toString();

            if (ahorroStr.isEmpty()) {
                Toast.makeText(this, "Ingresa un monto para ahorrar", Toast.LENGTH_SHORT).show();
                return;
            }

            double monto = Double.parseDouble(ahorroStr);
            if (monto <= 0) {
                Toast.makeText(this, "El monto debe ser mayor a cero", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.rawQuery("SELECT ahorro, CapitalTotal FROM Money WHERE UsuarioID = ?", new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                double ahorroActual = cursor.getDouble(cursor.getColumnIndexOrThrow("ahorro"));
                double capitalActual = cursor.getDouble(cursor.getColumnIndexOrThrow("CapitalTotal"));

                if (monto > capitalActual) {
                    Toast.makeText(this, "No tienes suficiente capital total para ahorrar esa cantidad", Toast.LENGTH_SHORT).show();
                    cursor.close();
                    db.close();
                    return;
                }

                double nuevoAhorro = ahorroActual + monto;
                double nuevoCapital = capitalActual - monto;

                // Actualizar ambos campos: ahorro y CapitalTotal
                db.execSQL("UPDATE Money SET ahorro = ?, CapitalTotal = ? WHERE UsuarioID = ?", new Object[]{nuevoAhorro, nuevoCapital, userId});

                Toast.makeText(this, "Ahorro registrado correctamente", Toast.LENGTH_SHORT).show();
                editAhorro.setText("");
            } else {
                Toast.makeText(this, "No se encontró registro de dinero para el usuario", Toast.LENGTH_SHORT).show();
            }

            cursor.close();
            db.close();
        }

    }