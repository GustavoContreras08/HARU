package com.example.haru;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AjustActivity extends BaseActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ajust);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton buttonCasa = findViewById(R.id.imageButton4);
        buttonCasa.setOnClickListener(v -> ajusahome());

        ImageButton buttonHist = findViewById(R.id.imageButton5);
        buttonHist.setOnClickListener(v -> ajusahisto());

        ImageButton buttonAjust = findViewById(R.id.imageButton);
        buttonAjust.setOnClickListener(v -> ajusaharu());
    }

    private void ajusahome() {
        Intent intent = new Intent(AjustActivity.this, CasaActivity.class);
        startActivity(intent);
    }

    private void ajusaharu() {
        Intent intent = new Intent(AjustActivity.this, HaruActivity.class);
        startActivity(intent);
    }

    private void ajusahisto() {
        Intent intent = new Intent(AjustActivity.this, HaruActivity.class);
        startActivity(intent);
    }
}