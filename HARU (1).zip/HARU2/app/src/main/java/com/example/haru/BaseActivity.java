package com.example.haru;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class BaseActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor lightSensor;

    // Umbrales con histéresis
    private static final float UMBRAL_OSCURO = 10f; // Baja sensibilidad
    private static final float UMBRAL_CLARO = 30f; // Evita que cambie demasiado rápido

    private static int lastMode = -1;
    private static long lastChangeTime = 0;
    private static final long DELAY_MS = 2000; // Esperar 2 segundos antes de cambiar

    // Para suavizar la lectura
    private static final int FILTER_SIZE = 5;
    private float[] luxBuffer = new float[FILTER_SIZE];
    private int bufferIndex = 0;
    private boolean bufferFull = false;

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
            if (lightSensor != null) {
                sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Guardar la lectura en el buffer
        luxBuffer[bufferIndex] = event.values[0];
        bufferIndex = (bufferIndex + 1) % FILTER_SIZE;
        if (bufferIndex == 0) bufferFull = true;

        // Calcular promedio
        float sum = 0;
        int count = bufferFull ? FILTER_SIZE : bufferIndex;
        for (int i = 0; i < count; i++) sum += luxBuffer[i];
        float avgLux = sum / count;

        long now = System.currentTimeMillis();
        int newMode = lastMode;

        if (avgLux < UMBRAL_OSCURO && lastMode != AppCompatDelegate.MODE_NIGHT_YES) {
            if (now - lastChangeTime > DELAY_MS) {
                newMode = AppCompatDelegate.MODE_NIGHT_YES;
                lastChangeTime = now;
            }
        } else if (avgLux > UMBRAL_CLARO && lastMode != AppCompatDelegate.MODE_NIGHT_NO) {
            if (now - lastChangeTime > DELAY_MS) {
                newMode = AppCompatDelegate.MODE_NIGHT_NO;
                lastChangeTime = now;
            }
        }

        if (newMode != lastMode && newMode != -1) {
            lastMode = newMode;
            AppCompatDelegate.setDefaultNightMode(newMode);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
