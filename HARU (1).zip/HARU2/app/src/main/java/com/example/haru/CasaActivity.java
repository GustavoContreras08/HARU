package com.example.haru;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Locale;

public class CasaActivity extends BaseActivity  {

    private int userId;
    private TextView tvGastos;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_casa);

        userId = getIntent().getIntExtra("USER_ID", -1);

        // Inicializa views y helper
        tvGastos = findViewById(R.id.tvGastos);
        dbHelper = new DatabaseHelper(this);

        mostrarCapitalTotal(userId);
        mostrarAhorros(userId);
        mostrarTotalGastos(userId);
        mostrarTotalIngresos(userId);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        FloatingActionButton fab = findViewById(R.id.fabMenu);
        fab.setOnClickListener(v -> mostrarMenu(v));

        ImageButton buttonreg = findViewById(R.id.imageButton2);
        buttonreg.setOnClickListener(v -> homeaharu());

        ImageButton buttonhist = findViewById(R.id.imageButton5);
        buttonhist.setOnClickListener(v -> homeahisto());

        ImageButton buttonajus = findViewById(R.id.imageButton);
        buttonajus.setOnClickListener(v -> homeaajust());
    }

    private void mostrarCapitalTotal(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT CapitalTotal FROM Money WHERE UsuarioID = ?",
                new String[]{String.valueOf(userId)}
        );

        TextView pSaldo = findViewById(R.id.pSaldo);

        if (cursor.moveToFirst()) {
            double capitalTotal = cursor.getDouble(cursor.getColumnIndexOrThrow("CapitalTotal"));
            pSaldo.setText(String.format(Locale.getDefault(), "%.2f", capitalTotal));
        } else {
            pSaldo.setText("0.00"); // si no hay registro
        }

        cursor.close();
        db.close();
    }

    private void mostrarAhorros(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        TextView tvAhorros = findViewById(R.id.tvAhorros);

        String query = "SELECT ahorro FROM Money WHERE UsuarioID = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)})) {
            if (cursor.moveToFirst()) {
                double ahorro = cursor.getDouble(cursor.getColumnIndexOrThrow("ahorro"));
                tvAhorros.setText(String.format(Locale.getDefault(), "$%.2f", ahorro));
            } else {
                tvAhorros.setText("$0.00");
            }
        } catch (Exception e) {
            e.printStackTrace();
            tvAhorros.setText("Error");
        } finally {
            db.close();
        }
    }

    private void mostrarTotalGastos(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Consulta para sumar gastos filtrando por usuario
        String query = "SELECT SUM(Monto) FROM Gasto WHERE UsuarioID = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            double totalGastos = cursor.isNull(0) ? 0 : cursor.getDouble(0);
            tvGastos.setText(String.format(Locale.getDefault(), "$%.2f", totalGastos));
        } else {
            tvGastos.setText("$0.00");
        }

        cursor.close();
        db.close();
    }

    private void mostrarMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menu_popup, popup.getMenu());
        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_gasto) {
                Toast.makeText(CasaActivity.this, "Gasto seleccionado", Toast.LENGTH_SHORT).show();
                homeagasto();
                return true;
            } else if (id == R.id.menu_ingreso) {
                Toast.makeText(CasaActivity.this, "Ingreso seleccionado", Toast.LENGTH_SHORT).show();
                homeaing();
                return true;
            } else if (id == R.id.menu_ahorro) {
                Toast.makeText(CasaActivity.this, "Ahorro seleccionado", Toast.LENGTH_SHORT).show();
                homeaarro();
                return true;
            } else {
                return false;
            }
        });
        popup.show();
    }

    private void homeaharu() {
        Intent intent = new Intent(CasaActivity.this, HaruActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void homeahisto() {
        Intent intent = new Intent(CasaActivity.this, HistoActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void homeaajust() {
        Intent intent = new Intent(CasaActivity.this, AjustActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void homeagasto() {
        Intent intent = new Intent(CasaActivity.this, GastoActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void homeaing() {
        Intent intent = new Intent(CasaActivity.this, IngresoActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void homeaarro() {
        Intent intent = new Intent(CasaActivity.this, AhorroActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void mostrarTotalIngresos(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT SUM(Monto) FROM Ingreso WHERE UsuarioID = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        TextView tvIngresos = findViewById(R.id.tvIngresos);

        if (cursor.moveToFirst()) {
            double totalIngresos = cursor.isNull(0) ? 0 : cursor.getDouble(0);
            tvIngresos.setText(String.format(Locale.getDefault(), "$%.2f", totalIngresos));
        } else {
            tvIngresos.setText("$0.00");
        }

        cursor.close();
        db.close();
    }

}
