    package com.example.haru;

    import android.content.Context;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;
    import android.database.sqlite.SQLiteOpenHelper;

    import java.util.Collections;
    import java.util.List;
    import java.util.ArrayList;


    public class DatabaseHelper extends SQLiteOpenHelper {

        private static final String DATABASE_NAME = "MiFinanzas.db";
        private static final int DATABASE_VERSION = 1;

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE IF NOT EXISTS Usuarios (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Nombre TEXT NOT NULL, " +
                    "Usuario TEXT NOT NULL UNIQUE, " +
                    "Password TEXT NOT NULL)");

            db.execSQL("CREATE TABLE IF NOT EXISTS Ingreso (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Monto REAL NOT NULL, " +
                    "DescripcionIng TEXT, " +
                    "UsuarioID INTEGER, " +
                    "Fecha TEXT, " +
                    "FOREIGN KEY (UsuarioID) REFERENCES Usuarios(id))");

            db.execSQL("CREATE TABLE IF NOT EXISTS Gasto (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Monto REAL NOT NULL, " +
                    "Descripcion TEXT, " +
                    "Frasco INTEGER, " +
                    "UsuarioID INTEGER, " +
                    "Fecha TEXT, " +
                    "FOREIGN KEY (UsuarioID) REFERENCES Usuarios(id))");

            db.execSQL("CREATE TABLE IF NOT EXISTS Money (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "CapitalTotal REAL, " +
                    "ahorro REAL, " +
                    "salario REAL, " +
                    "UsuarioID INTEGER, " +
                    "FOREIGN KEY (UsuarioID) REFERENCES Usuarios(id))");
        }

        // Método llamado si se actualiza la versión de la base de datos
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS Money");
            db.execSQL("DROP TABLE IF EXISTS Usuarios");
            db.execSQL("DROP TABLE IF EXISTS Gasto");
            db.execSQL("DROP TABLE IF EXISTS Ingreso");
            onCreate(db);
        }
        public float[] obtenerTotalesPorFrasco(int usuarioId) {
            SQLiteDatabase db = this.getReadableDatabase();

            float totalEsencial = 0;
            float totalDiversion = 0;

            String query = "SELECT Frasco, SUM(Monto) as Total " +
                    "FROM Gasto " +
                    "WHERE UsuarioID = ? " +
                    "GROUP BY Frasco";

            Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(usuarioId)});

            if (cursor.moveToFirst()) {
                do {
                    String frasco = cursor.getString(cursor.getColumnIndexOrThrow("Frasco"));
                    float total = cursor.getFloat(cursor.getColumnIndexOrThrow("Total"));

                    if (frasco.equalsIgnoreCase("Esencial")) {
                        totalEsencial = total;
                    } else if (frasco.equalsIgnoreCase("Diversión") || frasco.equalsIgnoreCase("Diversion")) {
                        totalDiversion = total;
                    }
                } while (cursor.moveToNext());
            }

            cursor.close();
            return new float[]{totalEsencial, totalDiversion};
        }

        public float obtenerPorcentajeAhorroSobreIngresos(int usuarioId) {
            SQLiteDatabase db = this.getReadableDatabase();
            float ahorro = 0;
            float totalIngresos = 0;

            // Obtener el ahorro desde tabla Money
            Cursor cursorAhorro = db.rawQuery("SELECT ahorro FROM Money WHERE UsuarioID = ?", new String[]{String.valueOf(usuarioId)});
            if (cursorAhorro.moveToFirst()) {
                ahorro = cursorAhorro.getFloat(cursorAhorro.getColumnIndexOrThrow("ahorro"));
            }
            cursorAhorro.close();

            // Sumar todos los ingresos
            Cursor cursorIngresos = db.rawQuery("SELECT SUM(Monto) as TotalIngresos FROM Ingreso WHERE UsuarioID = ?", new String[]{String.valueOf(usuarioId)});
            if (cursorIngresos.moveToFirst()) {
                totalIngresos = cursorIngresos.getFloat(cursorIngresos.getColumnIndexOrThrow("TotalIngresos"));
            }
            cursorIngresos.close();
            db.close();

            if (totalIngresos == 0) return 0; // Evitar división por cero
            return (ahorro / totalIngresos) * 100;
        }

        public List<Movimiento> obtenerTodosLosMovimientos(int usuarioId) {
            List<Movimiento> movimientos = new ArrayList<>();
            SQLiteDatabase db = this.getReadableDatabase();

            // Consultar ingresos
            Cursor cursorIngresos = db.rawQuery(
                    "SELECT Monto, DescripcionIng, Fecha FROM Ingreso WHERE UsuarioID = ? ORDER BY Fecha DESC",
                    new String[]{String.valueOf(usuarioId)});
            if (cursorIngresos.moveToFirst()) {
                do {
                    float monto = cursorIngresos.getFloat(cursorIngresos.getColumnIndexOrThrow("Monto"));
                    String descripcion = cursorIngresos.getString(cursorIngresos.getColumnIndexOrThrow("DescripcionIng"));
                    String fecha = cursorIngresos.getString(cursorIngresos.getColumnIndexOrThrow("Fecha"));
                    movimientos.add(new Movimiento("Ingreso", descripcion != null ? descripcion : "", monto, fecha));
                } while (cursorIngresos.moveToNext());
            }
            cursorIngresos.close();

            // Consultar gastos
            Cursor cursorGastos = db.rawQuery(
                    "SELECT Monto, Descripcion, Fecha FROM Gasto WHERE UsuarioID = ? ORDER BY Fecha DESC",
                    new String[]{String.valueOf(usuarioId)});
            if (cursorGastos.moveToFirst()) {
                do {
                    float monto = cursorGastos.getFloat(cursorGastos.getColumnIndexOrThrow("Monto"));
                    String descripcion = cursorGastos.getString(cursorGastos.getColumnIndexOrThrow("Descripcion"));
                    String fecha = cursorGastos.getString(cursorGastos.getColumnIndexOrThrow("Fecha"));
                    movimientos.add(new Movimiento("Gasto", descripcion != null ? descripcion : "", monto, fecha));
                } while (cursorGastos.moveToNext());
            }
            cursorGastos.close();

            // Puedes ordenar la lista por fecha aquí si quieres, usando Collections.sort() y un Comparator
            // Pero ya las consultamos ordenadas DESC por separado, y la mezcla puede estar fuera de orden.

            db.close();

            // Ordenar todos los movimientos por fecha descendente:
            Collections.sort(movimientos, (m1, m2) -> m2.getFecha().compareTo(m1.getFecha()));

            return movimientos;
        }


    }