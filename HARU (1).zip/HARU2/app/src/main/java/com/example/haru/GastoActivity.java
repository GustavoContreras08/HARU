package com.example.haru;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GastoActivity extends BaseActivity  {

    private DatabaseHelper dbHelper;
    private EditText montoEditText;
    private EditText descripcionEditText;
    private Spinner tipoSpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gasto);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DatabaseHelper(this);

        montoEditText = findViewById(R.id.monto);
        descripcionEditText = findViewById(R.id.etDescripcion);
        tipoSpinner = findViewById(R.id.spinner);

        Button buttonir = findViewById(R.id.button2);
        buttonir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gastoacasa();
            }
        });

        Button buttonreg = findViewById(R.id.button6);
        buttonreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Registrar();
            }
        });

        String[] opciones = {"Esencial", "Diversión"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tipoSpinner.setAdapter(adapter);

        tipoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Puedes mostrar el tipo seleccionado si lo deseas
                String seleccion = parent.getItemAtPosition(position).toString();
                Toast.makeText(GastoActivity.this, "Seleccionado: " + seleccion, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No se seleccionó nada
            }
        });
    }

    private void gastoacasa() {
        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        Intent intent = new Intent(GastoActivity.this, CasaActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }

    private void Registrar() {
        String montoStr = montoEditText.getText().toString().trim();
        String descripcion = descripcionEditText.getText().toString().trim();
        String tipo = tipoSpinner.getSelectedItem().toString();

        if (montoStr.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa un monto", Toast.LENGTH_SHORT).show();
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Monto inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        String fecha = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("Monto", monto);
        values.put("Descripcion", descripcion);
        values.put("Frasco", tipo);
        values.put("UsuarioID", usuarioID);
        values.put("Fecha", fecha);

        long newRowId = db.insert("Gasto", null, values);

        if (newRowId != -1) {
            // Restar al capital
            db.execSQL("UPDATE Money SET CapitalTotal = IFNULL(CapitalTotal, 0) - ? WHERE UsuarioID = ?",
                    new Object[]{monto, usuarioID});

            Toast.makeText(this, "Gasto registrado correctamente", Toast.LENGTH_SHORT).show();

            // Volver a la pantalla principal
            Intent intent = new Intent(GastoActivity.this, CasaActivity.class);
            intent.putExtra("USER_ID", usuarioID);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Error al registrar gasto", Toast.LENGTH_SHORT).show();
        }
    }

}
