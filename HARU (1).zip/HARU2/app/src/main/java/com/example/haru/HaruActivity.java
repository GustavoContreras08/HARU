package com.example.haru;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HaruActivity extends BaseActivity  {

    private DatabaseHelper dbHelper;
    private TextView textEsencial, textDiversion, textPorcentaje;
    private int usuarioID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_haru);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DatabaseHelper(this);
        usuarioID = getIntent().getIntExtra("USER_ID", -1);

        textEsencial = findViewById(R.id.textEsencial);
        textDiversion = findViewById(R.id.textDiversion);
        textPorcentaje = findViewById(R.id.textCenterRing1);

        ImageButton buttonCasa = findViewById(R.id.imageButton4);
        buttonCasa.setOnClickListener(v -> homeaharu());

        ImageButton buttonHist = findViewById(R.id.imageButton5);
        buttonHist.setOnClickListener(v -> homeahisto());

        ImageButton buttonAjust = findViewById(R.id.imageButton);
        buttonAjust.setOnClickListener(v -> homeaajust());

        mostrarPorcentajeAhorro();
    }

    @Override
    protected void onResume() {
        super.onResume();
        actualizarTotales();
        mostrarPorcentajeAhorro();
    }

    private void actualizarTotales() {
        float[] totales = dbHelper.obtenerTotalesPorFrasco(usuarioID);
        float totalGasto = totales[0] + totales[1];

        float porcentajeEsencial = totalGasto > 0 ? (totales[0] / totalGasto) * 100 : 0;
        float porcentajeDiversion = totalGasto > 0 ? (totales[1] / totalGasto) * 100 : 0;

        textEsencial.setText(String.format("%.0f%%", porcentajeEsencial));
        textDiversion.setText(String.format("%.0f%%", porcentajeDiversion));
    }

    private void mostrarPorcentajeAhorro() {
        float porcentaje = dbHelper.obtenerPorcentajeAhorroSobreIngresos(usuarioID);
        String porcentajeTexto = String.format("%%%d", Math.round(porcentaje));
        textPorcentaje.setText(porcentajeTexto);
    }

    private void homeaharu() {
        Intent intent = new Intent(HaruActivity.this, CasaActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }

    private void homeahisto() {
        Intent intent = new Intent(HaruActivity.this, HistoActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }

    private void homeaajust() {
        Intent intent = new Intent(HaruActivity.this, AjustActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }
}
