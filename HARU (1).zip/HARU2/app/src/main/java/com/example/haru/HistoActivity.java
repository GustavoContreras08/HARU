package com.example.haru;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HistoActivity extends BaseActivity  {

    RecyclerView rvMovimientos;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_histo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rvMovimientos = findViewById(R.id.rvMovimientos);
        rvMovimientos.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DatabaseHelper(this);

        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        List<Movimiento> movimientos = dbHelper.obtenerTodosLosMovimientos(usuarioID);

        MovimientoAdapter adapter = new MovimientoAdapter(movimientos);
        rvMovimientos.setAdapter(adapter);

        ImageButton buttonajus = findViewById(R.id.imageButton);
        buttonajus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ajust();
            }
        });

        ImageButton buttonharu = findViewById(R.id.imageButton2);
        buttonharu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                haru();
            }
        });

        ImageButton buttonhome = findViewById(R.id.imageButton4);
        buttonhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                home();
            }
        });

    }

    private void haru() {
        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        Intent intent = new Intent(HistoActivity.this, HaruActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }

    private void home() {
        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        Intent intent = new Intent(HistoActivity.this, CasaActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }

    private void ajust() {
        int usuarioID = getIntent().getIntExtra("USER_ID", -1);
        Intent intent = new Intent(HistoActivity.this, AjustActivity.class);
        intent.putExtra("USER_ID", usuarioID);
        startActivity(intent);
    }
}