package com.example.haru;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class IngresoActivity extends BaseActivity  {

    private DatabaseHelper dbHelper;
    private EditText montoEditText;
    private EditText descripcionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ingreso);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button buttoncan = findViewById(R.id.cancelar);
        buttoncan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelar();
            }
        });

        dbHelper = new DatabaseHelper(this);

        montoEditText = findViewById(R.id.monto);
        descripcionEditText = findViewById(R.id.etUsername); // tu campo descripción


        Button buttonreg = findViewById(R.id.button6);
        buttonreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrar();
            }
        });
    }

    private void cancelar() {
        int usuarioID = getIntent().getIntExtra("USER_ID", -1); // recuperar el ID actual
        Intent intent = new Intent(IngresoActivity.this, CasaActivity.class);
        intent.putExtra("USER_ID", usuarioID); // reenviar el ID
        startActivity(intent);
        finish(); // opcional, para cerrar la actividad actual
    }


    private void registrar() {
        String montoStr = montoEditText.getText().toString().trim();
        String descripcion = descripcionEditText.getText().toString().trim();

        if (montoStr.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa un monto", Toast.LENGTH_SHORT).show();
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Monto inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        // Aquí deberías obtener el ID del usuario actual; para ejemplo usaré 1:
        int usuarioID = getIntent().getIntExtra("USER_ID", -1);

        String fecha = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // 1. Insertar el ingreso
        ContentValues values = new ContentValues();
        values.put("Monto", monto);
        values.put("DescripcionIng", descripcion);
        values.put("UsuarioID", usuarioID);
        values.put("Fecha", fecha);

        long newRowId = db.insert("Ingreso", null, values);

        if (newRowId != -1) {
            // 2. Sumar al capital actual
            db.execSQL("UPDATE Money SET CapitalTotal = IFNULL(CapitalTotal, 0) + ? WHERE UsuarioID = ?",
                    new Object[]{monto, usuarioID});

            Toast.makeText(this, "Ingreso registrado correctamente", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(IngresoActivity.this, CasaActivity.class);
            intent.putExtra("USER_ID", usuarioID);
            startActivity(intent);
            finish();
            montoEditText.setText("");
            descripcionEditText.setText("");
        } else {
            Toast.makeText(this, "Error al registrar ingreso", Toast.LENGTH_SHORT).show();
        }
    }

}