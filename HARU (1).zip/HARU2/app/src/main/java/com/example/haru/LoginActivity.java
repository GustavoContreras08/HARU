package com.example.haru;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 🔽 Configurar el botón para cambiar de actividad
        Button buttonc = findViewById(R.id.button6);
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                homeacasa();
            }
        });


        Button buttonreg = findViewById(R.id.button1);
        buttonreg.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            homeareg();
        }
    });
}
    private void homeacasa() {
        EditText etUsuario = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);

        String usuario = etUsuario.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (usuario.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM Usuarios WHERE Usuario = ? AND Password = ?",
                new String[]{usuario, password}
        );

        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));

            Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();

            Intent intentCasa = new Intent(LoginActivity.this, CasaActivity.class);
            intentCasa.putExtra("USER_ID", userId);
            startActivity(intentCasa);

            finish();

        } else {
            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
        db.close();
    }

    private void homeareg() {
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }
}
