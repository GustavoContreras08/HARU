package com.example.haru;

public class Movimiento {
    private String tipo; // "Ingreso" o "Gasto"
    private String descripcion;
    private float monto;
    private String fecha;

    public Movimiento(String tipo, String descripcion, float monto, String fecha) {
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
    }

    public String getTipo() { return tipo; }
    public String getDescripcion() { return descripcion; }
    public float getMonto() { return monto; }
    public String getFecha() { return fecha; }
}

