package com.example.haru;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MovimientoAdapter extends RecyclerView.Adapter<MovimientoAdapter.MovimientoViewHolder> {

    private List<Movimiento> movimientos;

    public MovimientoAdapter(List<Movimiento> movimientos) {
        this.movimientos = movimientos;
    }

    public static class MovimientoViewHolder extends RecyclerView.ViewHolder {
        TextView tvTipo, tvDescripcion, tvMonto, tvFecha;

        public MovimientoViewHolder(View itemView) {
            super(itemView);
            tvTipo = itemView.findViewById(R.id.tvTipo);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcion);
            tvMonto = itemView.findViewById(R.id.tvMonto);
            tvFecha = itemView.findViewById(R.id.tvFecha);
        }
    }

    @Override
    public MovimientoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movimiento, parent, false);
        return new MovimientoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MovimientoViewHolder holder, int position) {
        Movimiento mov = movimientos.get(position);
        holder.tvTipo.setText(mov.getTipo());
        holder.tvDescripcion.setText(mov.getDescripcion());
        holder.tvMonto.setText(String.format("%.2f", mov.getMonto()));
        holder.tvFecha.setText(mov.getFecha());

        // Cambiar color según tipo:
        if (mov.getTipo().equals("Ingreso")) {
            holder.tvMonto.setTextColor(Color.parseColor("#4CAF50")); // verde
        } else {
            holder.tvMonto.setTextColor(Color.parseColor("#F44336")); // rojo
        }
    }

    @Override
    public int getItemCount() {
        return movimientos.size();
    }
}
