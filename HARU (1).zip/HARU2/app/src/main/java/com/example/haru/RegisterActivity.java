package com.example.haru;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etNombre, etUsuario, etPassword;
    Button btnRegistrar;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etNombre = findViewById(R.id.etNombre);
        etUsuario = findViewById(R.id.etUsuario);
        etPassword = findViewById(R.id.etPassword);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        dbHelper = new DatabaseHelper(this);

        btnRegistrar.setOnClickListener(v -> registrarUsuario());
    }

    private void registrarUsuario() {
        String nombre = etNombre.getText().toString().trim();
        String usuario = etUsuario.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (nombre.isEmpty() || usuario.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Validar si el usuario ya existe
        Cursor cursor = db.rawQuery("SELECT id FROM Usuarios WHERE Usuario = ?", new String[]{usuario});
        if (cursor.moveToFirst()) {
            Toast.makeText(this, "Este nombre de usuario ya está registrado", Toast.LENGTH_SHORT).show();
            cursor.close();
            return;
        }
        cursor.close();

        // Insertar en Usuarios
        ContentValues values = new ContentValues();
        values.put("Nombre", nombre);
        values.put("Usuario", usuario);
        values.put("Password", password);

        long userId = db.insert("Usuarios", null, values);

        if (userId != -1) {
            // Insertar en Money con valores iniciales en 0
            ContentValues moneyValues = new ContentValues();
            moneyValues.put("CapitalTotal", 0.0);
            moneyValues.put("ahorro", 0.0);
            moneyValues.put("salario", 0.0);
            moneyValues.put("UsuarioID", userId);

            db.insert("Money", null, moneyValues);

            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
            finish(); // O redirige a otra pantalla
        } else {
            Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }
}
