package com.example.haru;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class RingView extends View {

    private Paint ringPaint;
    private float ringWidth = 40f;

    public RingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        ringPaint = new Paint();
        ringPaint.setAntiAlias(true);
        ringPaint.setColor(0xFF3DC9C9); // Color similar al de tu imagen
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(ringWidth);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float radius = Math.min(getWidth(), getHeight()) / 2f - ringWidth / 2f;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        canvas.drawCircle(cx, cy, radius, ringPaint);  // <-- ¡esto dibuja el anillo!
    }
}
